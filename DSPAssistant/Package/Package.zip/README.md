# Icarus Infinite Energy

## English

### Feature

1.Icarus Infinite Energy
2.4DPocket(bug fixed)
3.GodModeButton
4.DSPAutoSorter
5.Tenfold ItemStack
6.Double construction range

### Attention

Need install BepInEx

### ChangeLog

V1.0.0

Transfer from Icarus Infinite Energy mod

### RoadMap

> Add Option for all features

## 中文

### 现有功能

1.伊卡洛斯无限能量
2.四次元口袋(4DPocket，修复了打开物流塔报错的 bug)
3.上帝模式按钮(GodModeButton)
4.打开储物箱、背包自动整理(DSPAutoSorter)
5.10倍堆叠
6.2倍建造范围

### 注意事项

需安装 BepInEx

### 更新日志

V1.0.0

从 Icarus Infinite Energy mod 迁移

### 未来规划

>为所有功能添加开关
