# DSPAssistant

## English

### Feature

1.Icarus Infinite Energy

2.4DPocket(bug fixed)

3.GodModeButton

4.DSPAutoSorter

5.Multiple ItemStack

6.Multiple construction range

7.Multiple range of clickable building

### Default HotKey

|  Feature   | HotKey  |
|  ----  | ----  |
| 4DPocket  | End |

### Attention

Need install BepInEx

Feature switches are in the General section of the configuration file

### ChangeLog

v1.0.1

Add Option for all features

Add multiple modification for ItemStack

Add modify range of clickable building feature

V1.0.0

Transfer from Icarus Infinite Energy mod

### RoadMap

> Optimize UI interface

## 中文

### 现有功能

1.伊卡洛斯无限能量

2.四次元口袋(4DPocket，修复了打开物流塔报错的 bug)

3.上帝模式按钮(GodModeButton)

4.打开储物箱、背包自动整理(DSPAutoSorter)

5.多倍堆叠

6.多倍建造范围

7.多倍可点击建筑范围

### 默认热键

|  功能   | 热键  |
|  ----  | ----  |
| 4DPocket  | End |

### 注意事项

需安装 BepInEx

功能开关在配置文件的通用小节

### 更新日志

v1.0.1

为所有功能添加开关

为堆叠添加倍数修改

添加可点击建筑的范围

V1.0.0

从 Icarus Infinite Energy mod 迁移

### 未来规划

> 优化 UI 界面